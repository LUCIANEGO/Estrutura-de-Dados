# Exercícios de Estrutura de Dados em C#

Este repositório contém exercícios práticos da disciplina **Estrutura de Dados**, desenvolvidos em **C#** no Programiz Online Compiler, com foco em **manipulação de matrizes (arrays bidimensionais)**.

## 📚 Atividades

### **Atividade 1 – Acessar elementos da matriz**
Objetivo: acessar e exibir elementos específicos de uma matriz 3×4.

- Elemento na linha 1, coluna 3  
- Elemento na linha 2, coluna 1  
- Elemento na linha 3, coluna 4  

### **Atividade 2 – Manipulação de dados**
Objetivo: alterar valores em posições específicas da matriz.

- Alterar o valor da linha 2, coluna 1 para 12  
- Alterar o valor da linha 1, coluna 4 para 25  
- Alterar o valor da linha 3, coluna 2 para 55  

### **Atividade 3 – Soma de linhas**
Objetivo: somar todos os itens de cada linha e determinar qual linha tem a maior soma.

---

## 💼 Exemplo Real – Sistema de Vendas

Neste exemplo, uma matriz armazena as vendas semanais de 3 vendedores.  
Cada linha representa um vendedor, e cada coluna representa uma semana do mês.

O programa calcula o total de vendas de cada vendedor e informa quem vendeu mais.

---

## 🚀 Como executar no Programiz
1. Acesse [Programiz C# Compiler](https://www.programiz.com/csharp-programming/online-compiler).
2. Cole o código desejado.
3. Clique em **Run** para executar.

---

## 🛠 Tecnologias utilizadas
- Linguagem: **C#**
- Ambiente: **Programiz Online Compiler**
- Conceitos: **Matrizes (arrays bidimensionais)**, **loops aninhados**, **acesso e manipulação de dados**.

---

✍ **Autora:** Luciane Rodrigues  
📅 **Ano:** 2025  
📌 Exercícios da disciplina **Estrutura de Dados**
