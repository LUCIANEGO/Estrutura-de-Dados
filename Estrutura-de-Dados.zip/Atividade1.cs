using System;

class Program
{
    static void Main()
    {
        int[,] matriz = {
            { 10, 20, 30, 40 },
            { 50, 60, 70, 80 },
            { 90, 100, 110, 120 }
        };

        Console.WriteLine("Elemento na linha 1, coluna 3: " + matriz[0, 2]);
        Console.WriteLine("Elemento na linha 2, coluna 1: " + matriz[1, 0]);
        Console.WriteLine("Elemento na linha 3, coluna 4: " + matriz[2, 3]);
    }
}