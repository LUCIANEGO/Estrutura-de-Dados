using System;

class Program
{
    static void Main()
    {
        int[,] vendas = {
            { 1500, 2000, 1800, 2200 }, // Vendedor 1
            { 1700, 2500, 2300, 2100 }, // Vendedor 2
            { 2000, 1900, 2500, 2700 }  // Vendedor 3
        };

        int vendedorComMaiorVenda = -1;
        int maiorVendaTotal = int.MinValue;

        for (int i = 0; i < vendas.GetLength(0); i++)
        {
            int totalVendedor = 0;
            for (int j = 0; j < vendas.GetLength(1); j++)
            {
                totalVendedor += vendas[i, j];
            }

            Console.WriteLine($"Total de vendas do Vendedor {i + 1}: R$ {totalVendedor}");

            if (totalVendedor > maiorVendaTotal)
            {
                maiorVendaTotal = totalVendedor;
                vendedorComMaiorVenda = i + 1;
            }
        }

        Console.WriteLine($"
O vendedor com maior venda total foi o Vendedor {vendedorComMaiorVenda} com R$ {maiorVendaTotal} em vendas!");
    }
}