using System;

class Program
{
    static void Main()
    {
        int[,] matriz = {
            { 10, 20, 30, 40 },
            { 50, 60, 70, 80 },
            { 90, 100, 110, 120 }
        };

        matriz[1, 0] = 12;
        matriz[0, 3] = 25;
        matriz[2, 1] = 55;

        Console.WriteLine("Matriz após alterações:");
        for (int i = 0; i < matriz.GetLength(0); i++)
        {
            for (int j = 0; j < matriz.GetLength(1); j++)
            {
                Console.Write(matriz[i, j] + "\t");
            }
            Console.WriteLine();
        }
    }
}