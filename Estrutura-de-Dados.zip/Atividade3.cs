using System;

class Program
{
    static void Main()
    {
        int[,] matriz = {
            { 10, 20, 30, 40 },
            { 12, 60, 70, 80 },
            { 90, 55, 110, 120 }
        };

        int maiorSoma = int.MinValue;
        int linhaMaiorSoma = -1;

        for (int i = 0; i < matriz.GetLength(0); i++)
        {
            int somaLinha = 0;
            for (int j = 0; j < matriz.GetLength(1); j++)
            {
                somaLinha += matriz[i, j];
            }
            Console.WriteLine($"Soma da linha {i + 1}: {somaLinha}");

            if (somaLinha > maiorSoma)
            {
                maiorSoma = somaLinha;
                linhaMaiorSoma = i + 1;
            }
        }

        Console.WriteLine($"
A linha com maior soma é a linha {linhaMaiorSoma} com soma = {maiorSoma}");
    }
}